import math


def f(x):
    y = 4*math.sqrt(1-x**2)
    return y


