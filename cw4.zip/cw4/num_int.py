import math

def left_sum(f,a,b,n):
    dx=(b-a)/n
    lsum=0
    for i in range(n):
        xi = a+i*dx
        lsum += f(xi)
    return dx*lsum

