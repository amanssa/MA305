#!/usr/bin/env python 
import math
import my_funs 
import num_int 
"""
========================================================================
MA305 - CW 4: your name - date
Purpose: To implement Left Sum, Right Sum and Miiddle Sum  approximations 
         for a definite integral creating some user defined modules.  
========================================================================
"""


a=0.0
b=1.0 
exact=math.pi 

n=int(input('Enter the number of rectangles n:'))

approx1=num_int.left_sum(my_funs.f,a,b,n)
approx2=num_int.right_sum(my_funs.f,a,b,n)
approx3=num_int.middle_sum(my_funs.f,a,b,n)

error1=abs(approx1-exact)
error2=abs(approx2-exact)
error3=abs(approx3-exact)

print()
print("Results using {} rectangles:".format(n))
print("=============================================")
print("                 Approximation       Error")
print("  Left-Sum: \t {0:12.10f}\t {1:12.10f}".format(approx1, error1))
print(" Right-Sum: \t {0:12.10f}\t {1:12.10f}".format(approx2, error2))
print("   Mid-Sum: \t {0:12.10f}\t {1:12.10f}".format(approx3, error3))
print("=============================================")
print()



